<header>
    <div class="navbar navbar-inverse" role="navigation" id="slide-nav">
        <div class="container" id="idHeader">
            
      
            <div class="navbar-header">  
            <button type="button" class="navbar-toggle navbar-hamburger-slider" >  
                <span class="icon-bar"></span>  
                <span class="icon-bar"></span>  
                <span class="icon-bar"></span>  
            </button>  <a class="navbar-brand" href="index.php"><img src="favicon.ico" style="margin-top: -10px;"></a>  </div>
            <div id="slidemenu">   
            <ul class="nav navbar-nav">  
                <li><a href="index.php">Home</a></li> 
                <li><a href="i.php">Inventory List</a></li>  
                <li><a href="v.php">Vendor List</a></li> 
                <li><a href="rep.php">Sales Report</a></li> 
                <li><a href="admin.php">Admin</a></li>  
                
        </div>
    </div>
    </div>
</header>