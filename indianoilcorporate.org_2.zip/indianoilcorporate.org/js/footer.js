document.write("<div class='fluid-conatiner'> <div class='footer'> ");
document.write(" <p><b>Motor Part Shop Software</b> &copy; 2018 - 2019, All rights reserved,</p> ");
document.write(" <ul> ");
document.write(" <li><a href='index.php'>Home</a></li> ");
document.write(" <li><a href='https://lapalb.github.io'>About Us</a></li> ");
document.write(" <li><a href='https://lapalb.github.io'>Contact Us</a></li> ");
document.write(" </ul> ");
document.write(" </div> ");

