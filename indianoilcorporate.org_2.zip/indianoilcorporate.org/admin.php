<!doctype html>
<html>

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Admin Login | Motor Part Shop Software</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <!-- All Stylesheet -->
    <link rel="stylesheet" href="css/element.css">
    <link rel="stylesheet" href="style.css">
 
</head>

<body>
<div class="container">
<div class="jumbotron">
<form id="bigtech-contact-form" action="cms.php" method="post">
                                    
                                     <label for="name" style="color:#404040; font-size:16px; font-weight:bold;">Name:</label>
                                     <input class="form-control" name="email" type="email" placeholder="Your email*" required>
                                        
                                       <label for="password" style="color:#404040; font-size:16px; font-weight:bold;">Password:</label>
                                       <input class="form-control" name="pwd" type="password" placeholder="Your Password*" required>
                                       
                                        <button class="button comment-cntact active" type="submit">Submit</button>
                                       
</form>
</div>
</div>
</body>
</html>
        